with open("sample.txt","w") as f:
    f.write("Hello File")
print("File written successfully")
