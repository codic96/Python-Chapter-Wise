x = 10
pi = 3.14
text = "Python"
flag = True
print(type(x), type(pi), type(text), type(flag))
