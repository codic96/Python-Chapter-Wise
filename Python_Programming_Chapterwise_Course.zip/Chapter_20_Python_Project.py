print("Mini Project: Simple Calculator")
a=5
b=2
print("Sum =", a+b)
