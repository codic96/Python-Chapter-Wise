num = 10
if num > 0:
    print("Positive")
else:
    print("Non-positive")
